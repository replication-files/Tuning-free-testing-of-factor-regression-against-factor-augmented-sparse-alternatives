# Replication package

The replication package includes to subfolders: i) Empirical application, ii) Simulations.

## *lassoboot* package

The main package which contains all routines for our proposed procedure. The package is available on Github repo https://github.com/replication-files/Tuning-free-testing-of-factor-regression-against-factor-augmented-sparse-alternatives. 

## Empirical application

-- application.R the main file which runs the replication of the empirical application. All required packages are loaded within this file. The data used in the application is part of the package *lassoboot* which contains all routines to compute the test based on our procedure. 

-- data.R file generates the dataset we use in our empirical application. Downloads the data and applies relevant transformation to the time period reported in the paper. 

-- fabtestp.R file contains functions to compute the pvalues based on FabTest. Taken from journal's website.

-- fredmd-data.RData file stores the data. The same file is stored in 'bootml' package. 

## Simulations

-- testing.R the main file which runs the replication of the simulations. All required packages are loaded within this file. *lassoboot* package is used which contains all routines to compute the test based on our procedure. 

-- fabtest.R file contains functions to compute the test statistics based on FabTest. Taken from journal's website.

-- generate.R file is loaded in testing.R file. It contains the function which computes the DGPs.
