rm(list=ls())
# ------- SET WORKING DIRECTORY ------- #
if (! "rstudioapi" %in% installed.packages() ) install.packages("rstudioapi")
wd <- dirname(rstudioapi::getSourceEditorContext()$path)
setwd(wd)

# ------- PACKAGES ------- #
# List of packages used in fabtestp
.packages = c("ggplot2", "dplyr", "tidyr", "stats", "readr",
              "pracma", "SIS", "glmnet")

# Install CRAN packages (if not already installed)
.inst <- .packages %in% installed.packages()
if(length(.packages[!.inst]) > 0) install.packages(.packages[!.inst])
# Load package
load <- lapply(.packages, require, character.only=TRUE)
if (all(unlist(load))) print("packages loaded succesfully")

# package for our test: 
if (!"lassoboot" %in% installed.packages()) devtools::install_github("replication-files/Tuning-free-testing-of-factor-regression-against-factor-augmented-sparse-alternatives", build_vignettes = TRUE, force = TRUE)
require("lassoboot")

# FabTest code (taken as is from journal's website):
source("fabtestp.R")

# ------- DATA AND ANALYSIS ------- #
# load data (part of the package) - prepared in data.R file -
data("fredmd-data")

# ------- CPI as outcome ------- #
y <- data[-1,106]
nobs <- length(y)
x <- data[-(nobs+1),]
x <- t(t(x)-colMeans(x)) # -normalize the design matrix X
x <- t(t(x)/apply(x,2,sd))

set.seed(3) # to reproduce exactly
fit_lassoboot <- lassoboot::factorsparsetest(x, y, p.value = TRUE,
                                       nlambda = 2000, numboot = 2000)
pvalFOurTestCPI <-  fit_lassoboot$pvalue
pvalFabTestCPI <- fabtestp(as.matrix(y), as.matrix(x), nobs)

# ------- CPI as outcome with lag alone ------- #
y <- data[-1,106]
x <- data[-(nobs+1),-106]

x <- t(t(x)-colMeans(x)) # -normalize the design matrix X
x <- t(t(x)/apply(x,2,sd))
lagCPIU <- data[-(nobs+1),106]

set.seed(3)
fit_lassoboot <- lassoboot::factorsparsetest(x, y, w = lagCPIU, p.value = TRUE,
                                       nlambda = 2000, numboot = 2000)
pvalFOurTestCPIlag <- fit_lassoboot$pvalue

# ------- INDPRO as outcome ------- #
y <- data[-1,6]
x <- data[-(nobs+1),]
x <- t(t(x)-colMeans(x)) # -normalize the design matrix X
x <- t(t(x)/apply(x,2,sd))

#debugonce(lassofit)
set.seed(3)
fit_lassoboot <- lassoboot::factorsparsetest(x, y, p.value = TRUE,
                                       nlambda = 2000, numboot = 2000)
pvalFOurTestIP <- fit_lassoboot$pvalue
pvalFabTestIP <- fabtestp(as.matrix(y),as.matrix(x),nobs)


print("CPI results:")
print("Our test pvalue:")
print(round(pvalFOurTestCPI, digits = 3))
print("FabTest pvalue:")
print(round(pvalFabTestCPI, digits = 3))
print("Our test pvalue with lagged CPI in factor model:")
print(round(pvalFOurTestCPIlag, digits = 3))

print("IP PRO results:")
print("Our test pvalue:")
print(round(pvalFOurTestIP, digits = 3))
print("FabTest pvalue:")
print(round(pvalFabTestIP, digits = 3)) 