rm(list=ls())
# ------- SET WORKING DIRECTORY ------- #
if (! "rstudioapi" %in% installed.packages() ) install.packages("rstudioapi")
wd <- dirname(rstudioapi::getSourceEditorContext()$path)
setwd(wd)

# version 0.6.0 was used
if (!"fbi" %in% installed.packages()) devtools::install_github("cykbennie/fbi", build_vignettes = TRUE, force = TRUE)


# load data (already transformed)

filepath <- "https://files.stlouisfed.org/files/htdocs/fred-md/monthly/2022-12.csv"
data <- fredmd(filepath, date_start = as.Date("2009-07-01"), date_end = as.Date("2020-02-01"), transform = TRUE)
data("fredmd_description")

nnn <- colnames(data)
nnn <- nnn[-1]

data <- as.matrix(data[,-1])

save(data, file = "fredmd-data.RData")