generate <- function(T,p,rhoF,rhoU, rhoE,varE,K,m) {
  
  B = matrix(runif(p*K,-1,1), p, K)
  
  Ff <- matrix(0,T,K)
  Ff[1,] <- mvrnorm(1,rep(0,K),diag(K))
  for (i in (2:T)){
    Ff[i,] <- mvrnorm(1,rep(0,K),(1-rhoF^2)*diag(K)) + rhoF*Ff[i-1,]
  }
  
  Sigma <- matrix(0,p,p)
  for (i in 1:p){
    for (j in 1:p){
      Sigma[i,j] <- 0.6^(abs(i-j))
    }
  }
  
  U <- matrix(0,T,p)
  U[1,] <- mvrnorm(1,rep(0,p),Sigma)
  
  for (i in (2:T)){
    U[i,] <- mvrnorm(1,rep(0,p),(1-rhoU^2)*Sigma) + rhoU*U[i-1,]
  }
  
  x = Ff%*%t(B) + U
  
  
  E <- matrix(0,T,1)
  E[1] <- rnorm(1,0,varE)
  
  
  for (i in (2:T)){
    E[i] <- rnorm(1,0,(1-rhoE^2)*varE) + rhoE*E[i-1]
  }
  
  beta = c(1,0.5,rep(0, times = p-2))*m
  
  y = x%*%beta + Ff%*%rep(0.5,K) + E
  
  return(list("x"=x,"y"=y))
}