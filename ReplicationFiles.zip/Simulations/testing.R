rm(list=ls())
# ------- SET WORKING DIRECTORY ------- #
if (! "rstudioapi" %in% installed.packages() ) install.packages("rstudioapi")
wd <- dirname(rstudioapi::getSourceEditorContext()$path)
setwd(wd)

# ------- PACKAGES ------- #
# List of packages used in fabtestp
.packages = c("Matrix", "tictoc", "foreach", "parallel", "doParallel", "doRNG",
              "SIS", "MASS", "glmnet")

# Install CRAN packages (if not already installed)
.inst <- .packages %in% installed.packages()
if(length(.packages[!.inst]) > 0) install.packages(.packages[!.inst])
# Load package
load <- lapply(.packages, require, character.only=TRUE)
if (all(unlist(load))) print("packages loaded succesfully")

# package for our test: 
if (!"lassoboot" %in% installed.packages()) devtools::install_github("replication-files/Tuning-free-testing-of-factor-regression-against-factor-augmented-sparse-alternatives", build_vignettes = TRUE, force = TRUE)
require("lassoboot")

# FabTest code (taken as is from journal's website):
source("fabtest.R")

# function that generates DGP:
source("generate.R")


# ------- MAIN CODE ------- #
tic()
nrep <- 2000

nrcore <- 40
cl <- makeCluster(mc <- getOption("cl.cores", nrcore))
registerDoParallel(cl)

set.seed(3)

mlist = c(0,0.1,0.2,0.3,0.4)
T = 200
p = 200
DGP = 2
varE = 1
if (DGP==1){
  rhoF = 0
  rhoU = 0
  rhoE = 0
}

if (DGP == 2){
  rhoF = 0.6
  rhoU = 0.1
  rhoE = 0
}

if (DGP == 3){
  rhoF = 0.6
  rhoU = 0.1
  rhoE = 0.1
}

K = 2

save <- matrix(rep(0,5*6), 5,6)

tic()
for (k in (1:5)){ m <- mlist[k]
res <- foreach(k = 1:nrep, .combine='cbind', .packages = c("lassoboot","Matrix","MASS","glmnet","SIS")) %dorng% {
  
  dataset <- generate(T,p,rhoF,rhoU, rhoE,varE,K,m)
  x <- dataset$x
  y <- dataset$y
  
  #Estimation of number of factors with the growth ratio estimator
  Rmax <- 10
  S <- svd(x,nu=Rmax,nv=Rmax)
  storesvd <- rep(0,Rmax-1)
  
  for (j in 1:(Rmax-1)){
    storesvd[j] <- S$d[j]/S$d[j+1]
  }
  Rhat <- which.max(storesvd)
  
  MF <- diag(T)-S$u[,1:Rhat]%*%t(S$u[,1:Rhat])
  
  hatU <- MF%*%x
  tildeY <- MF%*%y
  
  #Our test
  nbr.bootstraps <- 200
  nlambda <- 200
  fitLV <- lassoboot::lassofit(x = hatU, y = tildeY, nlambda = nlambda, numboot = nbr.bootstraps)
  
  #Fan et al (2023)'s test
  fabTest <- fabtest(y,x,T)
  
  c(fitLV$reject,fabTest)
}
save[k,] <- rowMeans(res,na.rm=TRUE)
print(k)
}


filename <- paste ("T", T, "varE", varE , "DGP", DGP, ".csv" ,sep = "")

write.csv(save, filename)

toc()